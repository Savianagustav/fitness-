# Analysis of fitness data
Project completed during internship at MedTourEasy
